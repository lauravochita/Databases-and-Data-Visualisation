#Name and category of each product
SELECT name, category FROM Product;

# Count the number of distinct products
SELECT COUNT(DISTINCT name) FROM Product;

#The number of categories the distinct products belong to
SELECT COUNT(DISTINCT category) FROM Product;

#The name of every customer
select distinct name from Customer

#Customers not belonging to Germany
select distinct name from Customer where country != 'Germany'

#Top 10 customers with most orders (by name)
select o.customer_name, count(*) as num_orders
from Customer c, Orders o
where c.name = o.customer_name
group by o.customer_name
order by num_orders desc limit 10

#Most money spent by customer name
select o.customer_name, sum(l.total_price) as total_spent
from Customer c, Orders o, Order_Line l
where c.name = o.customer_name and o.id = l.order_id
group by o.customer_name
order by total_spent desc limit 10

#Top 10 products by most units ordered
select p.name, sum(l.quantity) as total_units
from Product p, Order_Line l
where p.name = l.product_name
group by p.name
order by total_units desc limit 10

#Top 10 products by total revenue
select p.name, sum(l.total_price) as total_revenue
from Product p, Order_line l
where p.name = l.product_name
group by p.name
order by total_revenue desc limit 10

#Total number of orders, the average order amount and average order quantity per month
select o.date_year as year, o.date_month as month, count(distinct o.id) as num_orders, round(avg(l.total_price),2) as avg_order_amount, round(avg(l.quantity),2) as avg_order_quality
from Orders o, Order_Line l
where o.id = l.order_id
group by o.date_year, o.date_month

#Total number of orders, the average order amount and average order quantity per quarter
select o.date_year as year, quarter(o.date_full) as quarter, count(distinct o.id) as num_orders, round(avg(l.total_price), 2) as avg_order_amount, round(avg(l.quantity), 2) as avg_order_quantity
from Orders o, Order_line l
where o.id = l.order_id
group by o.date_year, quarter(o.date_full)